#!/bin/bash

############################################################
# Copyright (c) 2004-2014 Parallels IP Holdings GmbH.
# All rights reserved.
# http://www.parallels.com
############################################################


TOOLS_DIR="/usr/lib/parallels-tools"
BACKUP_DIR="/var/lib/parallels-tools"

prl_check_version()
{
	os_version=$("$TOOLS_DIR/installer/pm.sh" --os-ver)
	os_old_version=$([ -r "$BACKUP_DIR/os.version" ] && cat "$BACKUP_DIR/os.version")
	xorg_version=$("$TOOLS_DIR/installer/detect-xserver.sh" --xver)
	xorg_old_version=$([ -r "$BACKUP_DIR/xorg.version" ] && cat "$BACKUP_DIR/xorg.version")
	[[ $os_old_version != $os_version && ! -z $os_version && ! -z $os_old_version ]] && return 1
	[[ $xorg_old_version != $xorg_version && ! -z $xorg_version && ! -z $xorg_old_version ]] && return 2
	return 0
}

prl_install_tools()
{
	"$TOOLS_DIR/install" --install-unattended-with-deps \
		--restore-on-fail > /dev/null 2>&1
}

prl_install_xorg()
{
	"$TOOLS_DIR/install" --install-unattended-with-deps \
		--restore-on-fail > /dev/null 2>&1
}

# Check options passed in.
check_opts()
{
	for ARG in "$@"
	do
		case $ARG in
			-i)
				prl_check_version
				result=$?
				[ $result -eq 1 ] && prl_install_tools && exit $?
				[ $result -eq 2 ] && prl_install_xorg && exit $?
				exit $result
				;;
			*)
				echo "Not valid argument was sent."
				exit 3
				;;
		esac
	done
}

if [ "$#" -eq "0" ]; then
	echo "No arguments specified"
else
	check_opts "$@"
fi

exit 0
