#!/bin/bash
####################################################################################################
# @file prl-opengl-switcher.sh
#
# Set and unset parallels OpenGL libraries
#
# @author ksenks@
# @author owner is anatolykh@
#
# Copyright (c) 2005-2010 Parallels Holdings, Ltd. and its affiliates
# All rights reserved.
# http://www.parallels.com
#####################################################################################################


TOOL_DIR="/usr/lib/parallels-tools/tools"
TOOL_DIR_ARCH= # directories: /url/lib/parallels-tools/tools/prltools(.x64) 
TOOLS_X32="prltools"
TOOLS_X64="prltools.x64"

ARCH=$(uname -m)
LD_ARCH_64='x86-64'

DETECT_XSERVER="$TOOL_DIR/../installer/detect-xserver.sh"
VERSION="$TOOL_DIR/../version"
IBACKUP_DIR="/var/lib/parallels-tools"
BUILD_VER="1.0.0"
[ -e "$VERSION" ] && BUILD_VER=$(cat "$VERSION")

if [ ! -d "$TOOL_DIR/../.backup" ]; then
	BACKUP_DIR="$IBACKUP_DIR/.backup"
else
	BACKUP_DIR="$TOOL_DIR/../.backup"
fi

LIBGL_BACKUP_DIR="$BACKUP_DIR/.libgl"
LIBGL_BACKUP="$BACKUP_DIR/.libgl.list"
LIBGL_BACKUP_TMP="$BACKUP_DIR/.libgl.list.tmp"
PRL_LIBGL_BACKUP="$BACKUP_DIR/.prl.libgl.list"

XVER=
XMODSSRC=
XMODS=

LDCONFIG="/sbin/ldconfig"

####################################################################################################
# Definition of error codes
####################################################################################################
E_NOERR=0
E_FAIL=1
E_NOPARAM=150
E_NOTOOLS=151
E_NOXVER=152
E_NOXMOD=153

####################################################################################################
# Set tools directory depends of system architecture
####################################################################################################
set_tools_dir() {
	if [ -n "$TOOL_DIR" ]; then
		if [ "$ARCH" = "x86_64" ]; then
			TOOL_DIR_ARCH="$TOOL_DIR/$TOOLS_X64"
		else
			TOOL_DIR_ARCH="$TOOL_DIR/$TOOLS_X32"
		fi
	else
		echo "Error: Can not detect tools directory for arch $ARCH"
		return $E_FAIL
	fi
}

check_executable() {
	if [ ! -x "$1" ]; then
		echo "Error: No scipt or it's not executable by path $1"
		return $E_FAIL
	fi
}

set_xserver_version() {
	check_executable "$DETECT_XSERVER" || return $E_FAIL
	XVER=$($DETECT_XSERVER -v)
	if [ $? -ne 0 ]; then
		echo "Error: Can not detect x server version"
		return $E_FAIL
	fi
}

set_xmod_dir() {
	check_executable "$DETECT_XSERVER" || return $E_FAIL
	XMODS=$($DETECT_XSERVER -d)
	if [ $? -ne 0 ]; then
		echo "Error: Can not detect x server modules directory"
		return $E_FAIL
	fi
}

set_xmodsrc_dir() {
	check_executable "$DETECT_XSERVER" || return $E_FAIL
	XMODSSRC=$($DETECT_XSERVER -dsrc $TOOL_DIR_ARCH)
	if [ $? -ne 0 ]; then
		echo "Error: Can not detect x server modules install source directory"
		return $E_FAIL
	fi
}

install_libglx() {
        ext_dir="$XMODS/extensions"
	prl_xmods="$XMODSSRC"
	libglx_src="$prl_xmods"/usr/lib/libglx.so.1.0.0
	if [ ! -e "$libglx_src" ]; then
		echo "Error: No parallels libglx lib by path $libglx_src"
		return $E_FAIL
	fi

	echo "Backuping system library libglx.so..."
	for lib in $(ls -1 "$ext_dir"/libglx.so*); do
		if [ ! -h "$lib" ]; then
			mv -f "$lib" "$LIBGL_BACKUP_DIR"/  
			echo "$lib" >> "$LIBGL_BACKUP"
		else
			rm -f "$lib"
		fi
	done

	libglx_dst="$ext_dir"/libglx.so."$BUILD_VER"
	echo "Installing parallels libglx.so ($libglx_src as $libglx_dst)..."
	[ -e "$ext_dir" ] || mkdir -p "$ext_dir"
	LANG=C cp -vf "$libglx_src" "$libglx_dst"\
		| awk '{ print $3 }' | tr -d \`\' >> "$PRL_LIBGL_BACKUP"
	ln -s "libglx.so.$BUILD_VER" "$ext_dir"/libglx.so && \
		echo "$ext_dir"/libglx.so >> "$PRL_LIBGL_BACKUP"
}

install_libGL() {
	# install libGL.so library 
	# Input parameters: 
	# $1 - flag, has 0 value needs to install 32-bit version of library, 
	# and 1 for installing 64-bit version

	# Detect location of system libGL.so
	user_space_32=1
	libGLs=$($LDCONFIG -p | grep libGL.so.1)
	if [ $1 -eq 0 ]; then
		libGLs=$(echo "$libGLs" | grep -v "$LD_ARCH_64")
		if [ -z "$libGLs" ]; then
			echo "No installed 32-bit libGL.so on system."
			return $E_FAIL
		fi
		user_space_32=0
	else
		libGLs=$(echo "$libGLs" | grep "$LD_ARCH_64")
		if [ -z "$libGLs" ]; then
			echo "No installed 64-bit libGL.so on system."
			return $E_FAIL
		fi
	fi
	libGL_path=$(echo "$libGLs" | head -1 | awk -F"=> " '{print $2}')

	# Unpack PT directory for 32-bit user space modeules if needs
	postfix=""
	TOOLS_DIR_LIBGL="$TOOL_DIR_ARCH"	
	if [ $user_space_32 -eq 0 -a "$ARCH" = "x86_64" ]; then
		postfix=".32"
	    TOOLS_DIR_X32="$TOOL_DIR/$TOOLS_X32"	
		if [ ! -e "$TOOLS_DIR_X32" ]; then
			mkdir -p "$TOOLS_DIR_X32"
			tar -xzf "$TOOLS_DIR_X32.tar.gz" -C "$TOOLS_DIR_X32"
		fi
		TOOLS_DIR_LIBGL="$TOOLS_DIR_X32"
	fi
	
	libGL_src="$TOOLS_DIR_LIBGL"/xorg.7.1/usr/lib/libGL.so.1.0.0
	if [ ! -e "$libGL_src" ]; then
		echo "Error: No parallels libGL library by path $libGL_src"
		return $E_FAIL
	fi
	
	libGL_dir=$(dirname $libGL_path)		
	echo "Backuping system library libGL.so..."
	for lib in $(ls "$libGL_dir"/libGL.so*); do
		if [ ! -h "$lib" ]; then
			mv -f "${lib}" "$LIBGL_BACKUP_DIR/${lib##*/}${postfix}"
			echo "${lib}${postfix}" >> "$LIBGL_BACKUP"
		fi
	done
	
	libGL_dst="$libGL_dir"/libGL.so."$BUILD_VER"
	echo "Installing parallels libGL.so ($libGL_src as $libGL_dst)..."
	LANG=C cp -vf "$libGL_src" "$libGL_dst"\
		| awk '{ print $3 }' | tr -d \`\' >> "$PRL_LIBGL_BACKUP"

	# Fix libGL.so.1 link
	$LDCONFIG "$libGL_dst"

	# Fix libGL.so link if it is broken
	[ -e "$libGL_dir"/libGL.so ] || ln -sf libGL.so.1 "$libGL_dir"/libGL.so
}

set_prl_opengl() {
	set_tools_dir || exit $E_NOTOOLS
	set_xserver_version || exit $E_NOXVER
	set_xmod_dir || exit $E_NOXMOD
	set_xmodsrc_dir || exit $E_NOXMOD

	[ -e "$LIBGL_BACKUP_DIR" ] || mkdir -p "$LIBGL_BACKUP_DIR"	
	install_libglx || exit $E_FAIL
	
	# Locate and fix 32-bit libGL.so
	install_libGL 0
	ret=$?
	# Locate and fix 64-bit libGL.so
	install_libGL 1
	if [ $? -ne 0 -a $ret -ne 0 ]; then
		exit $E_FAIL
	fi
}

check_lib_is_prl() {
	type strings >/dev/null 2>&1 || return 0
	strings "$1" | grep -q 'Parallels Inc' || return 1
	echo "$1" |
		grep -qE '\.[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+$'
}

unset_prl_opengl() {
	if [ -e "$PRL_LIBGL_BACKUP" ]; then
		echo "Remove tools according to $PRL_LIBGL_BACKUP file"
		cat "$PRL_LIBGL_BACKUP" | while read line; do
			rm -f "$line"
		done
		rm -f "$PRL_LIBGL_BACKUP"
	fi

	IFS=$'\n'
	while read path; do
		lib=${path##*/}
		dst_path=${path%.32}
		src_path=$LIBGL_BACKUP_DIR/$lib

		# Sometimes after previous installations our libs are left.
		# Need to clean up then, not restore.
		if check_lib_is_prl "$src_path"; then
			echo "Library ${lib} is from Parallels. Removing it."
			rm -f "$src_path"
			continue
		fi

		echo "Restore original library ${lib%.32} to the path '$dst_path'"
		mv -f "$src_path" "$dst_path"
		# restore links on libGL.so
		echo "$lib" | grep -q libGL && $LDCONFIG "$dst_path"
	done <"$LIBGL_BACKUP"
	unset IFS

	# Restore symlink to libglx.so
	set_xmod_dir || exit $E_NOXMOD
	ext_dir="$XMODS/extensions"
	libglx_path="$ext_dir/libglx.so"
	if [ ! -e "$libglx_path" ]; then
		libglx_max=$(ls -v "$ext_dir"/libglx.so.* 2>/dev/null | tail -n1)
		if [ -n "$libglx_max" ]; then
			libglx_max=${libglx_max##*/}
			echo "Linking libglx.so to $libglx_max"
			ln -s "$libglx_max" "$libglx_path"
		else
			echo "Cannot create link for libglx.so"
		fi
	fi

	# Remove libgl backup data
	rm -rf "$LIBGL_BACKUP_DIR"
	rm -f "$LIBGL_BACKUP"
}

check_prl_opengl() {
	[ -e "$PRL_LIBGL_BACKUP" ] || return $E_FAIL
	
	cat "$PRL_LIBGL_BACKUP" | while read line; do
		[ -e "$line" ] && line=$(echo "$line" | sed 's/^‘\(.*\)’$/\1/')
		[ -e "$line" ] || return $E_FAIL
	done
	
	echo "Parallels OpenGL libs are installed"
	return $E_NOERR
}

# Update backup of system OpenGL libraries
# to avoid problems after libs update
update_sys_backup() {
	if [ ! -e "$LIBGL_BACKUP" ]; then
		echo "System OpenGL libs are not backup yet"
		return
	fi
	cat "$LIBGL_BACKUP" | while read line; do
		upd_lib=1
		tmpl=$(echo $line | sed 's/\.so.*/\.so*/')
		for lib in $(ls $tmpl); do
			# Exclude parallels libs from system backup
			grep -q "$lib" "$PRL_LIBGL_BACKUP"
			if [ $? -ne 0 -a ! -L "$lib" ]; then
				echo "Update backup of system OpenGL library by path $line"
				mv -f "${lib}" "$LIBGL_BACKUP_DIR/"
				echo "${lib}" >> "$LIBGL_BACKUP_TMP"
				upd_lib=0
			fi
		done
		[ $upd_lib -eq 0 ] || echo "$line" >> "$LIBGL_BACKUP_TMP"
	done
	mv -f "$LIBGL_BACKUP_TMP" "$LIBGL_BACKUP"
}

case "$1" in
	--on)
		# Don't set prl OpenGL libs if they
		# are already set
		check_prl_opengl
		if [ $? -eq 0 ]; then
			update_sys_backup
			exit $E_NOERR
		fi
		set_prl_opengl
		;;
	--off)
		# Don't unset prl OpenGL libs if they
		# are not set
		check_prl_opengl
		if [ $? -eq 0 ]; then
			update_sys_backup
		else
			exit $E_NOERR
		fi
		unset_prl_opengl
		;;
	*)
		exit $E_NOPARAM
		;;
esac

exit $E_NOERR
